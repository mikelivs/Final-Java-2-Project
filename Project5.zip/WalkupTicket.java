//Michael Livingston
//CMSC256
//Java Project5 

public class WalkupTicket extends FixedPriceTicket {

	public WalkupTicket()
	{
	    super();

		setPrice(50.0);
		
	}
	
	
}
