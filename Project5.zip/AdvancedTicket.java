//Michael Livingston
//CMSC256
//Java Project5 
public class AdvancedTicket extends Ticket{  //intiate class that extends ticket for inheritance 
private double price;

	public AdvancedTicket(int days) //paramarterized constructor 
	{
		try{
		if(days< 0) //test for negative days 
		{
			throw new IllegalArgumentException(); //throw exception 
		}
		
		if(days>=10)
		{
			price = 30.0;
		}
		else
		{
			price = 40.0;
		}
		}
		catch(IllegalArgumentException e)
		{
			System.out.println(">>>>>Price cannont be negative");
		}
		
	}
	
	public double getPrice() //getPrice method implemented
	{
		return price;
	}
	public void setPrice(double price1)
	{
		price = price1; 
	}
	}

