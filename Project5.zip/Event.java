import java.time.*;

//Michael Livingston
//CMSC256
//Java Project5 
public class Event {
private double price;
private String event;
private String date; //tried to use LocalDate type but was not taught how to implement it :/ 
private int maxNumber;
private int saleTicets;

public Event(){}

public Event(String eventTitle, double priceCost, String date, int maxNum, int salesTicket) throws IllegalArgumentException 
{
	setPrice(priceCost);
	setEvent(eventTitle);
	setDate(date);
	setMaxNumber(maxNum);
	setSaleTicets(salesTicket);
	
//	if(date.compareTo(other) ==-1)
//	{
//		throw new IllegalArgumentException("Past date for event");
//	}
}

public double getPrice()
{
	return price;
}

public void setPrice(double price) 
{
	try{
	if(price< 0)
	{
		throw new IllegalArgumentException();
	}
	else
	{
		this.price = price;
	}
	}
	catch(IllegalArgumentException e)
	{
		System.out.println(">>>>>Cannont be negative");
	}
}

public String getEvent() 

{
	return event;
}

public void setEvent(String event)
{
	this.event = event;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public int getMaxNumber() {
	return maxNumber;
}

public void setMaxNumber(int maxNumber) {
	try{
	if(maxNumber < 0)
	{
		throw new IllegalArgumentException();

	}
	else
	{
	this.maxNumber = maxNumber;
	}
	}
	catch(IllegalArgumentException e)
	{
		System.out.println(">>>>>Cannont be negative");
	}
}

public int getSaleTicets() 
{
	return saleTicets;
}

public void setSaleTicets(int saleTicets) 
{
	this.saleTicets = saleTicets;
}

public String toString()
{
	return "Event Title: "+ getEvent()+"\nPrice: " +getPrice()+"\nGet Date: "+getDate()+"\nMax Number: "+getMaxNumber()+"\n";
}
}
