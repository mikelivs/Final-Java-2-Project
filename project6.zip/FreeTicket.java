//Michael Livingston
//CMSC256
//Java Project5 
public class FreeTicket extends FixedPriceTicket{ //create Free ticket class that extends FixedPriceTicket

	public FreeTicket(){
		
		super(0); //use super to overide
	}

}
